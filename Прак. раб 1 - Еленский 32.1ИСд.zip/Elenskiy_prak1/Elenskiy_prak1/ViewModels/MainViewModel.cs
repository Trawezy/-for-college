﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;
using System.Xml.Linq;

namespace Elenskiy_prak1.ViewModels
{
    internal class MainViewModel : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler? PropertyChanged;

        public void OnPropertyChanged([CallerMemberName] string name = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }
        private byte _R;
        public byte R
        {
            get
            {
                return _R;
            }

            set
            {
                _R = value;
                OnPropertyChanged();
                UpdateColor();
            }
        }
        private byte _G;
        public byte G
        {
            get
            {
                return _G;
            }
            set
            {
                _G = value;
                OnPropertyChanged();
                UpdateColor();
            }
        }

        private byte _B;
        public byte B
        {
            get
            {
                return _B;
            }
            set
            {
                _B = value;
                OnPropertyChanged();
                UpdateColor();
            }
        }
        private Brush? _brush;
        public Brush Brush
        {
            get
            {
                return _brush;
            }
            set
            {
                _brush = value;
                OnPropertyChanged();
            }
        }
        public void UpdateColor()
        {
            Brush = new SolidColorBrush(Color.FromRgb(_R, _G, _B));

        }

        public DelegateCommand UpdateClipboardCommand
        {
            get
            {
                return new DelegateCommand(O => { UpdateClipboard(); });
            }
        }

        private void UpdateClipboard()
        {
            Clipboard.SetText(Color.FromRgb(_R, _G, _B).ToString());
        }
    }
}
